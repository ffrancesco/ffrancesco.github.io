function build_practice_models
% Creates three solved examples. Run in a fresh writable folder.
% Requires Simulink. Refuses to overwrite existing model files.
names = {'sol_arithmetic','sol_integration','sol_mass_spring_damper'};
for i = 1:numel(names)
 if bdIsLoaded(names{i}) || exist([names{i} '.slx'],'file')
  error('Model %s exists or is loaded. Use a fresh folder.',names{i});
 end
end
load_system('simulink');
for i = 1:numel(names)
 new_system(names{i});
 set_param(names{i},'Solver','ode45','MaxStep','0.02','StopTime','10');
end
m=names{1};
b(m,'Sources/Constant','A',[20 30 60 60],'Value','10');
b(m,'Sources/Constant','B',[20 100 60 130],'Value','4');
b(m,'Math Operations/Sum','Subtract',[120 45 150 105],'Inputs','+-');
b(m,'Sources/Constant','Multiplier',[120 160 160 190],'Value','3');
b(m,'Math Operations/Product','Multiply',[220 55 260 110],'Inputs','**');
b(m,'Sources/Constant','Denominator',[220 170 260 200],'Value','2');
b(m,'Math Operations/Product','Divide',[330 65 370 120],'Inputs','*/');
b(m,'Sinks/Display','Result',[440 70 520 110]);
l(m,'A/1','Subtract/1'); l(m,'B/1','Subtract/2');
l(m,'Subtract/1','Multiply/1'); l(m,'Multiplier/1','Multiply/2');
l(m,'Multiply/1','Divide/1'); l(m,'Denominator/1','Divide/2');
l(m,'Divide/1','Result/1');
m=names{2}; set_param(m,'StopTime','5');
b(m,'Sources/Constant','Rate',[30 50 70 90],'Value','2');
b(m,'Continuous/Integrator','Value',[160 50 200 90],'InitialCondition','1');
b(m,'Sinks/Scope','Scope',[300 50 340 90]);
l(m,'Rate/1','Value/1'); l(m,'Value/1','Scope/1');
m=names{3};
b(m,'Sources/Step','Force',[30 60 70 100],'Time','1','Before','0','After','10','SampleTime','0');
b(m,'Math Operations/Sum','NetForce',[170 50 200 110],'Inputs','+--');
b(m,'Math Operations/Gain','InverseMass',[280 60 340 100],'Gain','1/2');
b(m,'Continuous/Integrator','Velocity',[420 60 460 100],'InitialCondition','0');
b(m,'Continuous/Integrator','Displacement',[550 60 590 100],'InitialCondition','0');
b(m,'Math Operations/Gain','Damper',[280 170 340 210],'Gain','4','Orientation','left');
b(m,'Math Operations/Gain','Spring',[280 270 340 310],'Gain','20','Orientation','left');
b(m,'Sinks/Scope','Scope',[710 60 750 100]);
b(m,'Sinks/To Workspace','Log',[690 160 780 195],'VariableName','x_log','SaveFormat','Timeseries');
l(m,'Force/1','NetForce/1'); l(m,'NetForce/1','InverseMass/1');
l(m,'InverseMass/1','Velocity/1'); l(m,'Velocity/1','Displacement/1');
l(m,'Displacement/1','Scope/1'); l(m,'Displacement/1','Log/1');
l(m,'Velocity/1','Damper/1'); l(m,'Damper/1','NetForce/2');
l(m,'Displacement/1','Spring/1'); l(m,'Spring/1','NetForce/3');
for i=1:numel(names)
 set_param(names{i},'SimulationCommand','update');
 save_system(names{i}); open_system(names{i});
end
end
function b(m,lib,name,pos,varargin)
add_block(['simulink/' lib],[m '/' name],'Position',pos,varargin{:});
end
function l(m,src,dst)
add_line(m,src,dst,'autorouting','on');
end
