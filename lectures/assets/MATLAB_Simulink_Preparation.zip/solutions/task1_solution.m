%% Run from the folder containing displacement_data.csv
clear; close all; clc;
T = readtable('displacement_data.csv');
t = T.time_s;
x_mm = T.displacement_mm;
x = x_mm/1000;
figure; plot(t,x); grid on;
xlabel('Time [s]'); ylabel('Displacement [m]');
final_x = x(end)
[max_x,index] = max(x);
time_of_max = t(index)
mean_x = mean(x)
late = t >= 5;
x_late = x(late);
mean_late = mean(x_late)
figure; plot(t,x_mm); grid on; xlim([0 4]);
xlabel('Time [s]'); ylabel('Displacement [mm]');
title('Motion after a force is applied');
saveas(gcf,'task1_displacement.png');
