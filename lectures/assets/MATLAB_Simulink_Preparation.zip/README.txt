MATLAB & SIMULINK PREPARATION: A MOVING MASS
Revised scope: introductory software skills only.

START
Extract the ZIP and open MATLAB_Simulink_Preparation.html in a browser.
All slide runtime, fonts and figures are embedded for offline use.
Space advances, Esc shows overview, F reveals current-slide instructions.
19 slides, approximately 60-75 minutes.

TASK 1: MATLAB
Use displacement_data.csv (synthetic ideal mechanical motion, 501 rows).
Create variables, load columns, convert mm to m, plot, select values, find max.
Task 2: SIMULINK
Build an arithmetic calculator, then integrate a constant rate, then build a
mass-spring-damper model directly from m*a=F-c*v-k*x.
No signal filtering or feedback controller is taught in this preparation.

SOLUTIONS
Set MATLAB Current Folder to the extracted main folder, then:
 addpath('solutions')
 task1_solution
 build_practice_models
The builder creates sol_arithmetic.slx, sol_integration.slx and
sol_mass_spring_damper.slx. It refuses to overwrite existing models.
Requires MATLAB and Simulink only. It does not command hardware.

REFERENCE MODEL
Horizontal motion, m=2 kg, c=4 N*s/m, k=20 N/m, x(0)=v(0)=0.
Applied force steps from 0 to 10 N at t=1 s. Final displacement F/k=0.5 m.
For tau=max(t-1,0), exact displacement is:
 x=0.5*(1-exp(-tau)*(cos(3*tau)+sin(3*tau)/3)).
The first displacement peak is approximately 0.675 m at 2.047 s.
Spring/damper returning signal paths represent physical forces, not control.

VALIDATION
Reference data checked against the exact differential-equation solution.
MATLAB/Simulink unavailable during authoring: solution .m scripts need one run
on the teaching installation. No prebuilt .slx files are included.
